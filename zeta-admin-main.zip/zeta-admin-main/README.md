# Zeta Admin v3

Roblox için özelleştirilebilir bir admin paneli.  
İçerisinde fly, speed, teleport, kick, ban gibi komutları barındırır.

## Kullanım

```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/Sqew-cpu/Zeta-Admin/main/main.lua"))()
