export function isAdmin(name: string): boolean {
  const adminList = ["Sqew-cpu"];
  return adminList.includes(name);
}

export function sanitizeInput(input: string): string {
  return input.replace(/[^\w\s]/gi, "");
}